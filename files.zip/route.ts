import { NextRequest, NextResponse } from "next/server";

// Uses Resend (https://resend.com) - free 100 emails/day
// 1. Sign up at resend.com
// 2. Get your API key from the dashboard
// 3. Add to your .env.local: RESEND_API_KEY=re_xxxxxxxxxxxx
// 4. Optional: verify your domain for custom "from" address

export async function POST(req: NextRequest) {
  try {
    const { to, subject, body, ticketId } = await req.json();

    if (!to || !subject || !body) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "Email not configured. Add RESEND_API_KEY to your .env.local file." },
        { status: 500 }
      );
    }

    // Default "from" uses Resend's shared domain (works immediately, no setup needed)
    // To use your own domain: verify it in Resend dashboard, then change the from address
    const fromAddress = process.env.EMAIL_FROM || "Repair Shop <onboarding@resend.dev>";

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [to],
        subject,
        text: body,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      console.error("Resend error:", data);
      return NextResponse.json(
        { error: data.message || "Failed to send email" },
        { status: res.status }
      );
    }

    return NextResponse.json({ success: true, id: data.id });
  } catch (err) {
    console.error("Email API error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
