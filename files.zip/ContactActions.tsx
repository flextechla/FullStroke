"use client";

import { useState } from "react";

type Ticket = {
  id: string;
  invoice_number: string | null;
  customer_name: string | null;
  customer_email: string | null;
  customer_phone: string | null;
  equipment_type: string | null;
  equipment_brand: string | null;
  equipment_model: string | null;
  status: string;
  grand_total: number | null;
};

function formatStatus(status: string) {
  return status.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export default function ContactActions({ ticket }: { ticket: Ticket }) {
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showSmsModal, setShowSmsModal] = useState(false);
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const equipment = [ticket.equipment_brand, ticket.equipment_model, ticket.equipment_type]
    .filter(Boolean)
    .join(" ");

  const defaultSubject = `Update on your repair ${ticket.invoice_number || ""}`.trim();
  const defaultBody = `Hi ${ticket.customer_name || "there"},\n\nHere's an update on your repair order${ticket.invoice_number ? ` (${ticket.invoice_number})` : ""}${equipment ? ` for your ${equipment}` : ""}.\n\nCurrent status: ${formatStatus(ticket.status)}\n${ticket.grand_total != null ? `Current total: $${Number(ticket.grand_total).toFixed(2)}\n` : ""}\nPlease let us know if you have any questions.\n\nThank you!`;

  const defaultSms = `Hi ${ticket.customer_name || ""}! Update on your repair${ticket.invoice_number ? ` ${ticket.invoice_number}` : ""}: Status is "${formatStatus(ticket.status)}".${ticket.grand_total != null ? ` Total: $${Number(ticket.grand_total).toFixed(2)}.` : ""} Questions? Reply to this message.`;

  const [emailSubject, setEmailSubject] = useState(defaultSubject);
  const [emailBody, setEmailBody] = useState(defaultBody);
  const [smsBody, setSmsBody] = useState(defaultSms);

  async function sendEmail() {
    if (!ticket.customer_email) return;
    setSending(true);
    setResult(null);

    try {
      const res = await fetch("/api/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: ticket.customer_email,
          subject: emailSubject,
          body: emailBody,
          ticketId: ticket.id,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setResult({ success: true, message: "Email sent successfully!" });
        setTimeout(() => {
          setShowEmailModal(false);
          setResult(null);
        }, 2000);
      } else {
        setResult({ success: false, message: data.error || "Failed to send email" });
      }
    } catch {
      setResult({ success: false, message: "Failed to send email" });
    }

    setSending(false);
  }

  async function sendSms() {
    if (!ticket.customer_phone) return;
    setSending(true);
    setResult(null);

    try {
      const res = await fetch("/api/send-sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: ticket.customer_phone,
          body: smsBody,
          ticketId: ticket.id,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setResult({ success: true, message: "Text sent successfully!" });
        setTimeout(() => {
          setShowSmsModal(false);
          setResult(null);
        }, 2000);
      } else {
        setResult({ success: false, message: data.error || "Failed to send text" });
      }
    } catch {
      setResult({ success: false, message: "Failed to send text" });
    }

    setSending(false);
  }

  const inputStyle = {
    background: "var(--color-surface-2)",
    border: "1px solid var(--color-border-subtle)",
    color: "var(--color-text-primary)",
  } as React.CSSProperties;

  return (
    <>
      {/* Buttons */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => {
            setEmailSubject(defaultSubject);
            setEmailBody(defaultBody);
            setResult(null);
            setShowEmailModal(true);
          }}
          disabled={!ticket.customer_email}
          className="flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors disabled:opacity-40"
          style={{
            background: ticket.customer_email ? "rgba(59,130,246,0.1)" : "var(--color-surface-2)",
            color: ticket.customer_email ? "#3b82f6" : "var(--color-text-muted)",
          }}
          title={ticket.customer_email ? `Email ${ticket.customer_email}` : "No email on file"}
        >
          📧 Email Customer
        </button>

        <button
          onClick={() => {
            setSmsBody(defaultSms);
            setResult(null);
            setShowSmsModal(true);
          }}
          disabled={!ticket.customer_phone}
          className="flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors disabled:opacity-40"
          style={{
            background: ticket.customer_phone ? "rgba(34,197,94,0.1)" : "var(--color-surface-2)",
            color: ticket.customer_phone ? "#22c55e" : "var(--color-text-muted)",
          }}
          title={ticket.customer_phone ? `Text ${ticket.customer_phone}` : "No phone on file"}
        >
          💬 Text Customer
        </button>
      </div>

      {/* Email Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div
            className="w-full max-w-lg rounded-xl p-6 shadow-xl space-y-4"
            style={{
              background: "var(--color-surface-0)",
              border: "1px solid var(--color-border)",
            }}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold" style={{ color: "var(--color-text-primary)" }}>
                📧 Send Email
              </h3>
              <button
                onClick={() => setShowEmailModal(false)}
                className="rounded p-1 text-lg hover:opacity-70"
                style={{ color: "var(--color-text-muted)" }}
              >
                ✕
              </button>
            </div>

            <div className="text-sm" style={{ color: "var(--color-text-muted)" }}>
              To: <span style={{ color: "var(--color-text-primary)" }}>{ticket.customer_email}</span>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-muted)" }}>
                Subject
              </label>
              <input
                type="text"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                className="mt-1 block w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2"
                style={inputStyle}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-muted)" }}>
                Message
              </label>
              <textarea
                value={emailBody}
                onChange={(e) => setEmailBody(e.target.value)}
                rows={8}
                className="mt-1 block w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2"
                style={inputStyle}
              />
            </div>

            {result && (
              <div
                className="rounded-lg p-3 text-sm"
                style={{
                  background: result.success ? "rgba(34,197,94,0.1)" : "rgba(239,68,68,0.1)",
                  color: result.success ? "#22c55e" : "#ef4444",
                }}
              >
                {result.message}
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={sendEmail}
                disabled={sending}
                className="flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all hover:brightness-110 disabled:opacity-50"
                style={{ background: "#3b82f6", color: "#fff" }}
              >
                {sending ? "Sending..." : "Send Email"}
              </button>
              <button
                onClick={() => setShowEmailModal(false)}
                className="rounded-lg px-4 py-2.5 text-sm font-medium"
                style={{ color: "var(--color-text-secondary)", border: "1px solid var(--color-border)" }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SMS Modal */}
      {showSmsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div
            className="w-full max-w-lg rounded-xl p-6 shadow-xl space-y-4"
            style={{
              background: "var(--color-surface-0)",
              border: "1px solid var(--color-border)",
            }}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold" style={{ color: "var(--color-text-primary)" }}>
                💬 Send Text Message
              </h3>
              <button
                onClick={() => setShowSmsModal(false)}
                className="rounded p-1 text-lg hover:opacity-70"
                style={{ color: "var(--color-text-muted)" }}
              >
                ✕
              </button>
            </div>

            <div className="text-sm" style={{ color: "var(--color-text-muted)" }}>
              To: <span style={{ color: "var(--color-text-primary)" }}>{ticket.customer_phone}</span>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-muted)" }}>
                Message
              </label>
              <textarea
                value={smsBody}
                onChange={(e) => setSmsBody(e.target.value)}
                rows={4}
                className="mt-1 block w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2"
                style={inputStyle}
              />
              <p className="mt-1 text-xs" style={{ color: "var(--color-text-muted)" }}>
                {smsBody.length}/160 characters
              </p>
            </div>

            {result && (
              <div
                className="rounded-lg p-3 text-sm"
                style={{
                  background: result.success ? "rgba(34,197,94,0.1)" : "rgba(239,68,68,0.1)",
                  color: result.success ? "#22c55e" : "#ef4444",
                }}
              >
                {result.message}
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={sendSms}
                disabled={sending}
                className="flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all hover:brightness-110 disabled:opacity-50"
                style={{ background: "#22c55e", color: "#fff" }}
              >
                {sending ? "Sending..." : "Send Text"}
              </button>
              <button
                onClick={() => setShowSmsModal(false)}
                className="rounded-lg px-4 py-2.5 text-sm font-medium"
                style={{ color: "var(--color-text-secondary)", border: "1px solid var(--color-border)" }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
